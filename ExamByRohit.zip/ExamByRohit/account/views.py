from django.shortcuts import render, redirect
from .form import SignupForm, LoginForm, UserSignupForm, UserLoginForm, UserProfileForm
from django.contrib.auth import logout
from .models import Signup, UserSignup, UserProfile
from django.contrib.auth.decorators import login_required


def signup(request):
    if request.session.get('email', None):
        return redirect('login')
    email = None
    form = SignupForm()
    if request.method == 'POST':

        form = SignupForm(request.POST or None)
        if form.is_valid():
            form.save()
    data = {
        'form': form,
        'email': email
    }
    return render(request, 'signup.html', data)


def login(request):
    if request.session.get('username', None):
        return redirect('courseList')

    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user_auth = Signup.objects.filter(email=email, password=password)
            if user_auth.exists():
                print("Session:", type(request.session))
                request.session['email'] = email
                return redirect('courseList')

    data = {
        "form": form
    }
    return render(request, 'login.html', data)


def logout_view(request):
    logout(request)
    return redirect('login')


# user account view.......................................?

def user_signup(request):
    if redirect.session.get('myemail'):
        return redirect('Home')
    sign = UserSignupForm(request.POST or None)
    if sign.is_valid():
        sign.save()
    data = {
        'sign': sign,

    }
    return render(request, 'user_account/user_login.html', data)


def user_login(request):
    if request.session.get('myemail', None):
        return redirect('Home')

    sign = UserSignupForm(request.POST or None)
    if sign.is_valid():
        sign.save()

    form = LoginForm()
    if request.method == 'POST':
        form = UserLoginForm(request.POST or None)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user_auth = UserSignup.objects.filter(email=email, password=password)
            if user_auth.exists():
                print('session is created')
                request.session['myemail'] = email
                return redirect('Home')
            else:
                print('not match')

    data = {
        "form": form,
        'sign': sign,
    }
    return render(request, 'user_account/user_login.html', data)


@login_required
def user_profile(request):
    user_login = '!login'
    if not request.session.get('myemail', None):
        return redirect('user_login')
    else:
        user_login = request.session.get('myemail')

    s_obj = UserSignup.objects.get(email=user_login)
    pro = UserProfile.objects.filter(user=s_obj)
    print(pro)
    data = {
        'pro': pro,
        'user_login': user_login,
    }
    return render(request, 'user_account/user_profile.html', data)


def user_logout(request):
    logout(request)
    return redirect('user_login')
