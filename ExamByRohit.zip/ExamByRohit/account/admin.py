from django.contrib import admin
from .models import Signup, UserSignup, UserProfile


admin.site.register(Signup)
admin.site.register(UserSignup)
admin.site.register(UserProfile)
