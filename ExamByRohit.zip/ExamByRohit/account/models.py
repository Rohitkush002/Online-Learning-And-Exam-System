from django.db import models
import datetime
from tinymce.models import HTMLField
from django.db.models.signals import post_save
from django.dispatch import receiver


class Signup(models.Model):
    fname = models.CharField(max_length=50)
    lname = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=20)
    dob = models.DateField(default=datetime.date.today)

    def __str__(self):
        return self.email


class UserSignup(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=20)
    dob = models.DateField(default=datetime.date.today)

    def __str__(self):
        return self.name


class UserProfile(models.Model):
    user = models.OneToOneField(UserSignup, on_delete=models.CASCADE)
    profile_image = models.ImageField(default='post_default.png', upload_to='post')
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    dob = models.CharField(max_length=10, default='dd-mm-yy')
    bio = HTMLField()
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.name + " - " + self.created.strftime('%d-%m-%y')


@receiver(post_save, sender=UserSignup)
def user_create_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.created(user=instance)


post_save.connect(user_create_profile, sender=UserSignup)
