from django.urls import path
from . import views as account_view

urlpatterns = [
    path('signup/', account_view.signup, name='signup'),
    path('login/', account_view.login, name='login'),
    path('logout/', account_view.logout_view, name='logout'),
    path('', account_view.user_login, name='user_login'),
    path('user_signup/', account_view.user_signup, name='user_signup'),
    path('user_logout/', account_view.user_logout, name='userLogout'),
    path('user_profile/', account_view.user_profile, name='user_profile'),
]
