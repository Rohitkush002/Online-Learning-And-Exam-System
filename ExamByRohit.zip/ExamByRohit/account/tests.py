from django.test import TestCase

# Create your tests here.
# https://www.tutorialspoint.com/mongodb/mongodb_create_database.htm