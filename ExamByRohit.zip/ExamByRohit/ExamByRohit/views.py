from django.shortcuts import render


def index(request):
    return render(request, 'index.html')


def navbar(request):
    return render(request, 'navbar.html')


def sidebar(request):
    return render(request, 'main_page/sidebar.html')


def facebook(request):
    return render(request, 'user_page/facebook.html')
