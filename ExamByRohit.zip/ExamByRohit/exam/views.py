from django.shortcuts import render, redirect

from .models import ContactUs, CourseTopic, AboutCourseTopic
from django.contrib.auth import logout
from question.models import Course, Question
from django.contrib import messages
from django.contrib.auth.decorators import login_required


@login_required
def home(request):
    course = Course.objects.all()
    data = {
        'course': course,
    }
    return render(request, 'exam_page/home.html', data)


def contactus(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        auth = ContactUs.objects.filter(email=email)
        if auth.exists():
            messages.warning(request, 'Email df'
                                      'must be unique')
        else:
            data = ContactUs(name=name, email=email, subject=subject, message=message)
            data.save()

    return render(request, 'exam_page/contactus.html')


def user_course(request):
    course = Course.objects.all()
    data = {
        'course': course,
    }
    return render(request, 'exam_page/course.html', data)


def course_topic(request, name=None):
    c_obj = Course.objects.get(course=name)
    ct = CourseTopic.objects.filter(course=c_obj)

    data = {
        'ct': ct,
        'cor': c_obj.course,
        'desc': c_obj.desc
    }
    return render(request, 'exam_page/course_topic.html', data)


def about_topic(request, name=None):
    t_obj = CourseTopic.objects.get(topic=name)
    act = AboutCourseTopic.objects.filter(topic=t_obj)
    data = {
        'act': act,
        't_obj': t_obj.topic,

    }
    return render(request, 'exam_page/about_topic.html', data)


def userQuestion(request, name=None):
    obj = Course.objects.get(course=name)
    que = Question.objects.filter(course=obj)
    que1 = Question.objects.first()
    data = {
        'cql': que,
        'que1': que1,
        'obj': obj,
    }
    return render(request, 'exam_page/userQuestion.html', data)
