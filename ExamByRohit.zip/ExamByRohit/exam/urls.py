from django.urls import path
from . import views as exam_view

urlpatterns = [
    path('', exam_view.home, name='Home'),
    path('contactus', exam_view.contactus, name='ContactUs'),

    path('user_course/', exam_view.user_course, name='user_course'),

    path('course_topic/<str:name>/', exam_view.course_topic, name='course_topic'),
    path('about_topic/<str:name>/', exam_view.about_topic, name='about_topic'),

    path('userQuestion/<str:name>/', exam_view.userQuestion, name='userQuestion'),
]
