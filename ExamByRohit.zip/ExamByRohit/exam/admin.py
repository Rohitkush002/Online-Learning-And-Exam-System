from django.contrib import admin
from .models import (
    ContactUs,
    CourseTopic,
    AboutCourseTopic
)

admin.site.register(ContactUs)
admin.site.register(CourseTopic)
admin.site.register(AboutCourseTopic)
