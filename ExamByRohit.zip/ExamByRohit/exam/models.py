from django.db import models
from question.models import Course
import datetime
from tinymce.models import HTMLField


class ContactUs(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    subject = models.CharField(max_length=30)
    message = models.TextField()

    def __str__(self):
        return self.email


class CourseTopic(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    topic = models.CharField(max_length=100)

    def __str__(self):
        return self.topic


class AboutCourseTopic(models.Model):
    topic = models.ForeignKey(CourseTopic, on_delete=models.CASCADE)
    desc = HTMLField()

