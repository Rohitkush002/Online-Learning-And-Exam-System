# a = 2
# b = 10
# for i in range(1, 11):
#     for j in range(a, b + 1):
#         print(j * i, end='\t')
#
#     print()
#
# for i in range(10):
#     for j in range(1, 101, 10):
#         print(i + j, end='\t')
#     print()

# for i in range(10):
#     for j in range(1,101,10):
#         print(i+j,end="\t")
#     print()
#
# a=[1,2,3,4,5,6,7,8,9]
# print(a[::2])