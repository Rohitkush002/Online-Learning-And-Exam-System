import requests
from bs4 import BeautifulSoup

page = requests.get('https://www.sanfoundry.com/python-multiple-choice-questions-answers/')

soup = BeautifulSoup(page.text, 'html.parser')
for text in soup.findAll('div', {'sf-postw-category'}):
    for a in text.findAll('a'):
        print(a)
