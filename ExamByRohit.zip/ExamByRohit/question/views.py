from django.shortcuts import render, get_object_or_404, redirect
from .form import QuestionForm, CourseForm, TopicForm, AboutCourseTopicForm
from .models import Question, Course
from django.contrib import messages


def index(request):
    return render(request, 'question_page/index.html')


def question(request):
    form = QuestionForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.add_message(request, messages.INFO, 'Question Added SuccessFully......')
        return redirect('question')
    data = {
        'form': form
    }
    return render(request, 'question_page/question.html', data)


def questionList(request):
    ql = Question.objects.all()

    data = {
        'ql': ql,

    }
    return render(request, 'question_page/questionList.html', data)


def courseQuestionList(request, id):
    cql = Question.objects.filter(course_id=id)
    data = {
        'cql': cql
    }
    return render(request, 'question_page/courseQuestionList.html', data)


def delete(request, id):
    obj = Question.objects.get(id=id)

    obj.delete()
    return redirect('questionList')
    messages.success(request, 'Records Deleted Successfully....')

    return render(request, 'question_page/questionList.html')


def update(request, id=None):
    ql = get_object_or_404(Question, id=id)
    form = QuestionForm(request.POST or None, instance=ql)
    if form.is_valid():
        ql.save()
        return redirect('questionList')
    messages.success(request, 'Records Updated Successfully....')
    data = {
        'form': form,
        'ql': ql,
    }
    return render(request, 'question_page/update.html', data)


def course(request):
    form = CourseForm(request.POST, request.FILES or None)
    if form.is_valid():
        form.save()
        messages.add_message(request, messages.INFO, 'Course Added SuccessFully......')

        return redirect('course')
    data = {
        'form': form
    }
    return render(request, 'question_page/course.html', data)


def courseList(request):
    if request.method == 'POST':
        c_d = request.POST.getlist('instance')
        for c_id in c_d:
            Course.objects.get(id=c_id).delete()

    cl = Course.objects.all()
    data = {
        'cl': cl
    }
    return render(request, 'question_page/courseList.html', data)


def delete_course(request, id):
    obj = Course.objects.get(id=id)

    obj.delete()
    return redirect('courseList')

    return render(request, 'question_page/courseList.html')


def course_topic(request):
    form = TopicForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.add_message(request, messages.INFO, 'Topic Added SuccessFully......')
    data = {
        'form': form
    }
    return render(request, 'question_page/course_topic.html', data)


def topic_detail(request):
    form = AboutCourseTopicForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.add_message(request, messages.INFO, 'Topic Details Added SuccessFully......')
    data = {
        'form': form
    }
    return render(request, 'question_page/topic_detail.html', data)
