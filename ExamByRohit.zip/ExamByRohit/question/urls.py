from django.urls import path
from . import views as question_view

urlpatterns = [
    path('', question_view.index, name='index'),
    path('question/', question_view.question, name='question'),
    path('course/', question_view.course, name='course'),
    path('course_topic/', question_view.course_topic, name='course_topic'),
    path('topic_detail/', question_view.topic_detail, name='topic_detail'),
    path('questionList/', question_view.questionList, name='questionList'),
    path('courseQuestionList/<int:id>', question_view.courseQuestionList, name='courseQuestionList'),
    path('courseList/', question_view.courseList, name='courseList'),
    path('delete/<int:id>', question_view.delete, name='delete_Question'),
    path('deleteCourse/<int:id>', question_view.delete_course, name='delete_Course'),
    path('update/<int:id>', question_view.update, name='update_Question'),

]
