from django import forms
from .models import Question, Course
from exam.models import CourseTopic, AboutCourseTopic



class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = '__all__'


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = '__all__'

    course = forms.CharField(max_length=40,
                             label="Course",
                             widget=forms.TextInput(
                                 attrs={
                                     'class': 'form-control form-control-success',
                                 }))



class TopicForm(forms.ModelForm):
    class Meta:
        model = CourseTopic
        fields = '__all__'


class AboutCourseTopicForm(forms.ModelForm):
    class Meta:
        model = AboutCourseTopic
        fields = '__all__'
