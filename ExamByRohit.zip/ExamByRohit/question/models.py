from django.db import models
from tinymce.models import HTMLField


class Course(models.Model):
    image = models.ImageField(default='post_default.png', upload_to='post')
    course = models.CharField(max_length=50)
    title = models.CharField(max_length=300)
    desc = HTMLField()

    def __str__(self):
        return self.course


class Question(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    question = models.TextField(blank=True, null=True)
    option_1 = models.CharField(max_length=200)
    option_2 = models.CharField(max_length=200)
    option_3 = models.CharField(max_length=200)
    option_4 = models.CharField(max_length=200)
    answer = models.CharField(max_length=100)



    def __str__(self):
        return self.question
